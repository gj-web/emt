package mk.ukim.finki.mk.bookandstay_application.service.Impl;

import mk.ukim.finki.mk.bookandstay_application.dto.HousingDto;
import mk.ukim.finki.mk.bookandstay_application.model.Host;
import mk.ukim.finki.mk.bookandstay_application.model.Housing;
import mk.ukim.finki.mk.bookandstay_application.model.enumerations.Category;
import mk.ukim.finki.mk.bookandstay_application.repository.HousingRepository;
import mk.ukim.finki.mk.bookandstay_application.service.HostService;
import mk.ukim.finki.mk.bookandstay_application.service.HousingService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class HousingServiceImpl implements HousingService {

    private final HousingRepository housingRepository;
    private final HostService hostService;

    public HousingServiceImpl(HousingRepository housingRepository, HostService hostService) {
        this.housingRepository = housingRepository;
        this.hostService = hostService;
    }

    @Override
    public List<Housing> findAll() {
        return this.housingRepository.findAll();
    }

    @Override
    public Optional<Housing> save(HousingDto housing) {
        return Optional.of(this.housingRepository.save(new Housing(housing.getName(), housing.getCategory(), this.hostService.findById(housing.getHost()).orElseThrow(() -> new RuntimeException("Host not found")), housing.getNumRooms())));
    }

    @Override
    public Optional<Housing> findById(Long id) {
        return this.housingRepository.findById(id);
    }

    @Override
    public Optional<Housing> update(Long id, HousingDto housing) {
        return this.housingRepository.findById(id)
                .map(existingAccommodation -> {
                    if (housing.getName() != null) {
                        existingAccommodation.setName(housing.getName());
                    }
                    if (housing.getCategory() != null) {
                        existingAccommodation.setCategory(housing.getCategory());
                    }
                    if (housing.getHost() != null && this.hostService.findById(housing.getHost()).isPresent()) {
                        existingAccommodation.setHost(this.hostService.findById(housing.getHost()).get());
                    }
                    if (housing.getNumRooms() != null) {
                        existingAccommodation.setNumRooms(housing.getNumRooms());
                    }
                    return this.housingRepository.save(existingAccommodation);
                });
    }

    @Override
    public Optional<Housing> markedAsRented(Long id) {
        return housingRepository.findById(id).map(housing -> {
            housing.setNumRooms(null);
            return housingRepository.save(housing);
        });
    }

    @Override
    public void deleteById(Long id) {
        this.housingRepository.deleteById(id);
    }

    @Override
    public List<Housing> searchWithFilters(String name, Category category, Long hostId) {
        if (name != null && category != null && hostId != null) {
            return housingRepository.findAllByNameContainingIgnoreCaseAndCategoryAndHost_Id(name, category, hostId);
        } else if (name != null && category != null) {
            return housingRepository.findAllByNameContainingIgnoreCaseAndCategory(name, category);
        } else if (name != null && hostId != null) {
            return housingRepository.findAllByNameContainingIgnoreCaseAndHost_Id(name, hostId);
        } else if (category != null && hostId != null) {
            return housingRepository.findAllByCategoryAndHost_Id(category, hostId);
        } else if (name != null) {
            return housingRepository.findAllByNameContainingIgnoreCase(name);
        } else if (category != null) {
            return housingRepository.findAllByCategory(category);
        } else if (hostId != null) {
            return housingRepository.findAllByHost_Id(hostId);
        } else {
            return housingRepository.findAll();
        }
    }


}
