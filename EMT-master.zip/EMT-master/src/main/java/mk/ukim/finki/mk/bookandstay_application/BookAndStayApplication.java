package mk.ukim.finki.mk.bookandstay_application;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookAndStayApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookAndStayApplication.class, args);
	}

}
