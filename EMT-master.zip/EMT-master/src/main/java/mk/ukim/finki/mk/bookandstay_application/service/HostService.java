package mk.ukim.finki.mk.bookandstay_application.service;
import mk.ukim.finki.mk.bookandstay_application.dto.CountryDto;
import mk.ukim.finki.mk.bookandstay_application.dto.HostDto;
import mk.ukim.finki.mk.bookandstay_application.model.Country;
import mk.ukim.finki.mk.bookandstay_application.model.Host;

import java.util.List;
import java.util.Optional;

public interface HostService {
    List<Host> findAll();

    Optional<Host> save(HostDto host);

    Optional<Host> findById(Long id);

    Optional<Host> update(Long id, HostDto host);

    void deleteById(Long id);
}
