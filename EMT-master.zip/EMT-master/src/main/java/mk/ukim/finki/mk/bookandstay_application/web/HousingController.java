package mk.ukim.finki.mk.bookandstay_application.web;
import mk.ukim.finki.mk.bookandstay_application.dto.HousingDto;
import mk.ukim.finki.mk.bookandstay_application.model.Housing;
import mk.ukim.finki.mk.bookandstay_application.model.enumerations.Category;
import mk.ukim.finki.mk.bookandstay_application.service.HousingService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/housings")
public class HousingController {
    private final HousingService housingService;

    public HousingController(HousingService housingService) {
        this.housingService = housingService;
    }

    @GetMapping("/{id}")
    public ResponseEntity<Housing> findById(@PathVariable Long id) {
        return this.housingService.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping("/add")
    public ResponseEntity<Housing> save(@RequestBody HousingDto housing) {
        return this.housingService.save(housing)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PutMapping("/edit/{id}")
    public ResponseEntity<Housing> update(@PathVariable Long id, @RequestBody HousingDto housing) {
        return this.housingService.update(id, housing)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        if (this.housingService.findById(id).isPresent()) {
            this.housingService.deleteById(id);
            return ResponseEntity.ok().build();
        }
        return ResponseEntity.notFound().build();
    }

    @PutMapping("/rent/{id}")
    public ResponseEntity<Housing> markAsRented(@PathVariable Long id) {
        return this.housingService.markedAsRented(id)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @GetMapping
    public List<Housing> findAll(@RequestParam(required = false) String name,
                                 @RequestParam(required = false) Category category,
                                 @RequestParam(required = false) Long hostId) {
        if (name != null || category != null || hostId != null) {
            return this.housingService.searchWithFilters(name, category, hostId);
        }
        return this.housingService.findAll();
    }

}
