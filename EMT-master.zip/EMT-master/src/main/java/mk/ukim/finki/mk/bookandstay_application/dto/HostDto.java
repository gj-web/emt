package mk.ukim.finki.mk.bookandstay_application.dto;
import lombok.NoArgsConstructor;
import mk.ukim.finki.mk.bookandstay_application.model.Country;

@NoArgsConstructor
public class HostDto {
    private String name;

    private String surname;

    private Long country;

    public HostDto(String name, String surname, Long country) {
        this.name = name;
        this.surname = surname;
        this.country = country;
    }

    public String getName() {
        return name;
    }

    public Long getCountry() {
        return country;
    }

    public String getSurname() {
        return surname;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public void setCountry(Long country) {
        this.country = country;
    }
}
