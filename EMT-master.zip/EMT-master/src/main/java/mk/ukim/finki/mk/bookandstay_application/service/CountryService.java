package mk.ukim.finki.mk.bookandstay_application.service;
import mk.ukim.finki.mk.bookandstay_application.dto.CountryDto;
import mk.ukim.finki.mk.bookandstay_application.model.Country;
import java.util.List;
import java.util.Optional;

public interface CountryService {
    List<Country> findAll();

    Optional<Country> save(CountryDto country);

    Optional<Country> findById(Long id);

    Optional<Country> update(Long id, CountryDto country);

    void deleteById(Long id);

}
