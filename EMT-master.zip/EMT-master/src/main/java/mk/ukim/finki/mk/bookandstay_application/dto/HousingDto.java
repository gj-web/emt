package mk.ukim.finki.mk.bookandstay_application.dto;

import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.ManyToOne;
import lombok.NoArgsConstructor;
import mk.ukim.finki.mk.bookandstay_application.model.Host;
import mk.ukim.finki.mk.bookandstay_application.model.enumerations.Category;

@NoArgsConstructor
public class HousingDto {
    private String name;

    private Category category;

    private Long host;

    private Integer numRooms;

    public HousingDto(String name, Category category, Long host, Integer numRooms) {
        this.name = name;
        this.category = category;
        this.host = host;
        this.numRooms = numRooms;
    }

    public String getName() {
        return name;
    }

    public Category getCategory() {
        return category;
    }

    public Integer getNumRooms() {
        return numRooms;
    }

    public Long getHost() {
        return host;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setCategory(Category category) {
        this.category = category;
    }

    public void setHost(Long host) {
        this.host = host;
    }

    public void setNumRooms(Integer numRooms) {
        this.numRooms = numRooms;
    }
}
