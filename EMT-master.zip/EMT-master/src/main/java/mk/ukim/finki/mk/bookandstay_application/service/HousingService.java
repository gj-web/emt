package mk.ukim.finki.mk.bookandstay_application.service;
import mk.ukim.finki.mk.bookandstay_application.dto.CountryDto;
import mk.ukim.finki.mk.bookandstay_application.dto.HousingDto;
import mk.ukim.finki.mk.bookandstay_application.model.Country;
import mk.ukim.finki.mk.bookandstay_application.model.Housing;
import mk.ukim.finki.mk.bookandstay_application.model.enumerations.Category;

import javax.swing.text.html.Option;
import java.util.List;
import java.util.Optional;

public interface HousingService {
    List<Housing> findAll();

    Optional<Housing> save(HousingDto housing);

    Optional<Housing> findById(Long id);

    Optional<Housing> update(Long id, HousingDto housing);

    Optional<Housing> markedAsRented(Long id);

    void deleteById(Long id);

    List<Housing> searchWithFilters(String name, Category category, Long hostId);
}
